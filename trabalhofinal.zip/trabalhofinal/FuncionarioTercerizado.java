/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhofinal;


public class FuncionarioTercerizado extends Funcionario {
    
    private String dataInciodecontrato;
    private String dataFimdecontrato;
    private float valorContrato;

    public FuncionarioTercerizado(String dataInciodecontrato,String dataFimdecontrato,float valorContrato,String nome, String cpf, String cargo, double salario) {
        super(nome, cpf, cargo, salario);
        this.dataInciodecontrato = dataInciodecontrato;
        this.dataFimdecontrato =  dataFimdecontrato;
        this.valorContrato = valorContrato;


    }
    

//    public FuncionarioTercerizado(String nomeEmpresa, String nome, int idade, String cpf, String cargo, double salario) {
//        super(nome, idade, cpf, cargo, salario);
//        this.nomeEmpresa = nomeEmpresa;
//    }
//
//   
//    public String getNomeEmpresa() {
//        return nomeEmpresa;
//    }
//
//    public void setNomeEmpresa(String nomeEmpresa) {
//        this.nomeEmpresa = nomeEmpresa;
//    }
//
//    
//
    public double mostrarSalarioLiquido(){
        return  super.calcularImpostodeRenda(super.getSalario());
         
     }
   
   

    @Override
    public String toString() {
        return (super.toString() + "Nome da empresa = " + getNomeEmpresa()+  ",  Salario = " + mostrarSalarioLiquido());
    }

    private String getNomeEmpresa() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
