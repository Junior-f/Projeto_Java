
package trabalhofinal;


public interface Salario {
    
     double calculaSalarioLiquido();
    
}
