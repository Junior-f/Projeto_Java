
package trabalhofinal;


public interface Comissao {
    
   float calculaComissao();
    
}
