
package trabalhofinal;

import java.util.ArrayList;
import java.util.Scanner;


public class TrabalhoFinal {
   
    
    static Scanner input = new Scanner(System.in);
    static ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();  
    static Empresa e1 = new Empresa("FJ Seguranca",(float )30000.00,"04/07/2019","04/07/2020");
    
    public static void listarFuncionarioComissicao() {
       
      
		System.out.println("\n-----------Dados dos Funcionarios com Comisao--------");
		for (Funcionario a :funcionarios ) {
			if (a instanceof FuncionarioComissicao) {
                            FuncionarioComissicao aux = (FuncionarioComissicao)a;
                            
                            System.out.println(a);
				
			}
		}
	}
    
    public static void listarFuncionarioTemporario() {
       
      
		System.out.println("\n--------Dados dos Funcionarios Temporarios--------");
		for (Funcionario a :funcionarios ) {
			if (a instanceof FuncionarioTemporario) {
                            FuncionarioTemporario aux = (FuncionarioTemporario)a;
                            
                            System.out.println(a);
				
			}
		}
	}
    
    private static void cadastrarFuncionarioTemporario()  {
        
       
        System.out.println("Digite o nome do funcionario:");
        String nome = input.nextLine();
        System.out.println("Digite o cpf do funcionario:");
        String cpf = input.nextLine();
        System.out.println("Digite o cargo do funcionario:");
        String cargo = input.nextLine();
        System.out.println("Digite o salario do funcionario:");
        float salario = 0 ;
        try{
         salario = Float.parseFloat(input.nextLine());    
  
        }
        catch(NumberFormatException e){
            System.out.println("\nOcooreu um erro! Voce usou , para separar as casas decimais em vez de usar o . ou voce nao digitou o salario corretamente, Nao faca mais isso!\n");
        }
        System.out.println("Digite a data do inicio do contrato do funcionario:");
        String dataIncio = input.nextLine();
        System.out.println("Digite a data do fim  do contrato  do funcionario:");
        String dataFim = input.nextLine();
     
      funcionarios.add(new FuncionarioTemporario(dataIncio,dataFim,nome,cpf,cargo,salario));
        System.out.println("Funcionario cadastrado.");
    }
    private static void cadastrarFuncionarioComissicao() {
        
       
        System.out.println("Digite o nome do funcionario:");
        String nome = input.nextLine();
        System.out.println("Digite o cpf do funcionario:");
        String cpf = input.nextLine();
        System.out.println("Digite o cargo do funcionario:");
        String cargo = input.nextLine();
        System.out.println("Digite o salario do funcionario:");
        float salario = 0;
        try{
         salario = Float.parseFloat(input.nextLine());    
  
        }
        catch(NumberFormatException e){
           System.out.println("\nOcooreu um erro! Voce usou , para separar as casas decimais em vez de usar o . ou voce nao digitou o salario corretamente, Nao faca mais isso!\n");
        }
        System.out.println("Digite o valor de vendas do mes  do funcionario:");
        float vvendas = Float.parseFloat(input.nextLine()); 
       funcionarios.add(new FuncionarioComissicao(vvendas,nome,cpf,cargo,salario));
      
      System.out.println("Funcionario cadastrado.");
    }
     private static void cadastrarFuncionarioTercerizado() {
        
       
        System.out.println("Digite o nome do funcionario:");
        String nome = input.nextLine();
        System.out.println("Digite o cpf do funcionario:");
        String cpf = input.nextLine();
        System.out.println("Digite o cargo do funcionario:");
        String cargo = input.nextLine();
        System.out.println("Digite o salario do funcionario:");
        float salario = 0;
        try{
         salario = Float.parseFloat(input.nextLine());    
  
        }
        catch(NumberFormatException e){
            System.out.println("\nOcooreu um erro! Voce usou , para separar as casas decimais em vez de usar o . ou voce nao digitou o salario corretamente, Nao faca mais isso!\n");
        }
        
     e1.addFuncionario(new Funcionario(nome,cpf,cargo,salario));
        System.out.println("Funcionario cadastrado na Empresa FJ Seguranca.");
    }
   
    
    public static void main(String[] args) {
                
        int opc = 0;
        do {
            System.out.println("\n------ MENU --------");
            System.out.println("1 - Cadastrar Funcionario Temporario");
            System.out.println("2 - Cadastrar Funcionario com Comissao");
            System.out.println("3 - Cadastrar Funcionario Terceirazado na Empresa FJ Seguranca ");
            System.out.println("4 - Listar Funcionarios Temporario com seus salarios liquidos");
            System.out.println("5 - Listar Funcionarios com Comissao com seus salarios liquidos ");
            System.out.println("6 - Listar Funcionarios Tercerizados da Empresa FJ Seguranca com seus salarios liquidos");
            System.out.println("7 - Verificar Total gastos da FJ Seguranca com salarios ");
            System.out.println("8 - Verificar Lucro da FJ seguranca ");
            System.out.println("0 - Sair");

            opc = Integer.parseInt(input.nextLine());

            switch (opc) {
                case 1:
                    cadastrarFuncionarioTemporario();
                    break;

                case 2:
                    cadastrarFuncionarioComissicao();
                    break;

                case 3:
                 cadastrarFuncionarioTercerizado();
                    break;

                case 4:
                    listarFuncionarioTemporario();
                    break;

                case 5:
                    listarFuncionarioComissicao();
                    break;
                case 6:
                    e1.listarFuncionarios();
                    break;
                 case 7:
                     System.out.println("Total de Gastos da FJ seguranca com Salarios");
                    System.out.println("Total = " + e1.totalSalarios()); 
                    break;
                 case 8:
                   e1.lucroEmpresa();
                    break;
                 case 0:
                 System.out.println("Saindo");    
                    return;
                default:
                    System.out.println("Opção Inválida");
                    break;
                   
            }
        } while (opc != 0);

    
    }

    
    
    }
    

