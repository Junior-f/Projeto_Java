
package trabalhofinal;


public class FuncionarioTemporario extends Funcionario {
    private String dataIncio;
    private String dataFim;

    public FuncionarioTemporario(String dataIncio, String dataFim, String nome, String cpf, String cargo, float salario) {
        super(nome, cpf, cargo, salario);
        this.dataIncio = dataIncio;
        this.dataFim = dataFim;
    }

    public String getDataIncio() {
        return dataIncio;
    }

    public void setDataIncio(String dataIncio) {
        this.dataIncio = dataIncio;
    }

    public String getDataFim() {
        return dataFim;
    }

    public void setDataFim(String dataFim) {
        this.dataFim = dataFim;
    }
     
    @Override
    public String toString() {
        return (super.toString() + ",  data inicio do contrato = " + getDataIncio() + ",  data fim do contrato = " + getDataFim());
    }
    
}
