
package trabalhofinal;


public class FuncionarioComissicao extends Funcionario implements Comissao{

    private float valorVendas;

    public FuncionarioComissicao(float valorVendas, String nome, String cpf, String cargo, float salario) {
        super(nome, cpf, cargo, salario);
        this.valorVendas = valorVendas;
    }

    
    public float getValorVendas() {
        return valorVendas;
    }

    public void setValorVendas(float valorVendas) {
        this.valorVendas = valorVendas;
    }

   @Override
    public float calculaComissao() {
         float total =0 ;
        total = (float)  ((getValorVendas() * 10)/ 100);
        return total;
    }
    
   public float mostrarSalario(){
        
      return  super.calcularImpostodeRenda() + calculaComissao();
        
    }
     
    

    @Override
    public String toString() {
        return ( super.toString() + ",  Salario liquido do "+ super.getNome()+ " com comissao = "  + mostrarSalario());

    
    
    
}

    
}