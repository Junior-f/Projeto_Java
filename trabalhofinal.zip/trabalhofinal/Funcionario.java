
package trabalhofinal;


public class Funcionario  {
    private String nome;
    private String cpf;
    private String cargo;
    private float salario;

    public Funcionario(String nome, String cpf, String cargo, float salario) {
        this.nome = nome;
        this.cpf = cpf;
        this.cargo = cargo;
        this.salario = salario;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }


    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        if (salario > 0){
        this.salario = salario;
        }else{
            this.salario = 0;
        }
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    public float calcularInss(){
        float total =(float) getSalario();
        if(getSalario() > 0  && getSalario() <= 1751.81){
            
            total = (float) (getSalario() -((getSalario() * 8)/ 100));
            return total;
        }
        if(getSalario() > 1751.81 && getSalario() <= 2919.72){
            
           total = (float) (getSalario() -((getSalario() * 9)/ 100));
               
            return total;
        }
        if(getSalario() > 2919.72 && getSalario() <= 5839.45){
            
            total = (float) (getSalario() -((getSalario() * 11)/ 100));
            return total;
        }
        if(getSalario() > 5839.45){
            total = (float) (getSalario() - 642.34);
            return total;
        }
        return total;
        
         
    }
    
    public float calcularImpostodeRenda(){
        float total = 0;
        float salario = 0;
        total = (float)(calcularInss() - 189.59);
        
        if(total <= 1903.98){
            
            return total;
        }if( total > 1903.98 && total <=2826.65){
            
           salario = (float) ((total - ((total * 7.5)/ 100)) - 142.80);
           return salario;
        }
        if(total > 2826.65 && total >= 3751.05 ){
            
           salario = (float) ((total - ((total * 15)/ 100)) - 354.80);
            return salario;
        }
        if(total > 3751.05 && total >= 4664.68 ){
            
            salario = (float) ((total - ((total * 22.5)/ 100)) - 636.13);
            
             return salario ;
        }
        if(total > 4664.68){
              salario = (float) ((total - ((total * 27.5)/ 100)) - 869.36);
            
            return salario;
        }
        
        return total;
    }
    
    
    @Override
    public String toString() {
        return String.format("Funcionario " + "  Nome = " + getNome() + ", cpf = "  + getCpf() + ", Cargo = " + getCargo()+ ", Salario Liquido do " + getNome()+ " = %.2f " ,calcularImpostodeRenda() );
    }


   

    
    
    
}
